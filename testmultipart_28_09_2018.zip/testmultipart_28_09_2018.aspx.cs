﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestMutipartFormData
{
    public partial class testmultipart_28_09_2018 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Create a http request to the server endpoint that will pick up the
            // file and file description.
            HttpWebRequest requestToServerEndpoint =
            //(HttpWebRequest)WebRequest.Create("http://2.235.241.7:8080/bank-report-entries/Checking1/upload");
            (HttpWebRequest)WebRequest.Create("http://2.235.241.7:8080/bank-report-entries/2/upload");
            string boundaryString = "----SomeRandomText";
            string fileUrl = @"C:\GIT_LUCA\re2017\Re2017Software\Checking3-19.csv";

            // Set the http request header \\
            requestToServerEndpoint.Method = WebRequestMethods.Http.Post;
            requestToServerEndpoint.ContentType = "multipart/form-data; boundary=" + boundaryString;
            requestToServerEndpoint.KeepAlive = true;
            requestToServerEndpoint.Credentials = System.Net.CredentialCache.DefaultCredentials;

            // Use a MemoryStream to form the post data request,
            // so that we can get the content-length attribute.
            MemoryStream postDataStream = new MemoryStream();
            StreamWriter postDataWriter = new StreamWriter(postDataStream);

            // Include value from the myFileDescription text area in the post data
            postDataWriter.Write("\r\n--" + boundaryString + "\r\n");
            postDataWriter.Write("Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}",
            "myFileDescription",
            "A sample file description");

            // Include the file in the post data
            postDataWriter.Write("\r\n--" + boundaryString + "\r\n");
            //postDataWriter.Write("Content-Disposition: form-data;"
            //+ "name=\"{0}\";"
            //+ "filename=\"{1}\""
            //+ "\r\nContent-Type: {2}\r\n\r\n",
            //"myFile",
            //Path.GetFileName(fileUrl),
            //Path.GetExtension(fileUrl));
            postDataWriter.Write("Content-Disposition: form-data;"
          + "name=\"{0}\";"
          + "filename=\"{1}\""
          + "\r\nContent-Type: {2}\r\n\r\n",
          "myFile",
          Path.GetFileName(fileUrl),
          "text/plain");
            postDataWriter.Flush();

            // Read the file
            FileStream fileStream = new FileStream(fileUrl, FileMode.Open, FileAccess.Read);
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
            {
                postDataStream.Write(buffer, 0, bytesRead);
            }
            fileStream.Close();

            postDataWriter.Write("\r\n--" + boundaryString + "--\r\n");
            postDataWriter.Flush();

            // Set the http request body content length
            requestToServerEndpoint.ContentLength = postDataStream.Length;

            // Dump the post data from the memory stream to the request stream
            using (Stream s = requestToServerEndpoint.GetRequestStream())
            {
                postDataStream.WriteTo(s);
            }
            postDataStream.Close();



            // Grab the response from the server. WebException will be thrown
            // when a HTTP OK status is not returned
            WebResponse response = requestToServerEndpoint.GetResponse();
            StreamReader responseReader = new StreamReader(response.GetResponseStream());
            string replyFromServer = responseReader.ReadToEnd();
        }
    }
}