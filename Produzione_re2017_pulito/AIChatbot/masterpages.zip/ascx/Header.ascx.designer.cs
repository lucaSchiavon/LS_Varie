﻿//------------------------------------------------------------------------------
// <generato automaticamente>
//     Codice generato da uno strumento.
//
//     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
//     il codice viene rigenerato. 
// </generato automaticamente>
//------------------------------------------------------------------------------

namespace AQuest.ChatBotGsk.PigeonCms.pgn_content.ascx {
    
    
    public partial class Header {
        
        /// <summary>
        /// Controllo LblUsername.
        /// </summary>
        /// <remarks>
        /// Campo generato automaticamente.
        /// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label LblUsername;
        
        /// <summary>
        /// Controllo LateralMenu1.
        /// </summary>
        /// <remarks>
        /// Campo generato automaticamente.
        /// Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        /// </remarks>
        protected global::AQuest.ChatBotGsk.PigeonCms.pgn_content.ascx.LateralMenu LateralMenu1;
    }
}
