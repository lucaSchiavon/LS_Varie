﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestMutipartFormData
{
    public partial class FormUploadTest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string url = "http://2.235.241.7:8080/bank-report-entries/Checking1/upload";
            //string CT = "image/jpeg";
            string IdBank = "Checking1";
            string fullPath = @"C:\GIT_LUCA\re2017\Re2017Software\Checking3-19.csv";
            FormUpload2.FileParameter f = new FormUpload2.FileParameter(File.ReadAllBytes(fullPath), "Checking3-19.csv", "multipart/form-data");
            Dictionary<string, object> d = new Dictionary<string, object>();
            d.Add(IdBank, f);
            //d.Add(CT, f);
            //d.Add(name, f);
            string ua = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.121 Safari/535.2";
            FormUpload2.MultipartFormDataPost(url, ua, d);
        }
    }
}